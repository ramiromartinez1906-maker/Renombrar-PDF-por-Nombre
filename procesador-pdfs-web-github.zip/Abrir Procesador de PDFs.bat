@echo off
setlocal
cd /d "%~dp0"
python desktop_app.py
if errorlevel 1 (
    echo.
    echo No se pudo abrir la aplicacion.
    pause
)
endlocal
