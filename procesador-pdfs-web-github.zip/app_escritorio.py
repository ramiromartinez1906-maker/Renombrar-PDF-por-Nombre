from __future__ import annotations

import shutil
import tempfile
import zipfile
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from backend.procesar_recibos_por_nombre import extraer_nombre


class ProcesadorApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Procesador de PDFs por nombre")
        self.root.geometry("760x560")
        self.root.minsize(700, 520)
        self.root.configure(bg="#f2efe8")
        self.archivos: list[Path] = []
        self._crear_estilos()
        self._construir_interfaz()

    def _crear_estilos(self) -> None:
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Card.TFrame", background="#fffdf8")
        style.configure("Panel.TFrame", background="#f2efe8")
        style.configure("Title.TLabel", background="#fffdf8", foreground="#162033")
        style.configure("Body.TLabel", background="#fffdf8", foreground="#475467")
        style.configure("Accent.TButton", font=("Segoe UI", 10, "bold"))
        style.configure("Ghost.TButton", font=("Segoe UI", 10))

    def _construir_interfaz(self) -> None:
        contenedor = ttk.Frame(self.root, style="Panel.TFrame", padding=24)
        contenedor.pack(fill="both", expand=True)

        tarjeta = ttk.Frame(contenedor, style="Card.TFrame", padding=28)
        tarjeta.pack(fill="both", expand=True)

        ttk.Label(
            tarjeta,
            text="Procesador de PDFs por nombre",
            style="Title.TLabel",
            font=("Segoe UI Semibold", 22),
        ).pack(anchor="w")

        ttk.Label(
            tarjeta,
            text=(
                "Selecciona varios recibos PDF y genera un archivo ZIP con copias "
                "renombradas usando el campo Apellido y Nombres."
            ),
            style="Body.TLabel",
            font=("Segoe UI", 10),
            wraplength=620,
            justify="left",
        ).pack(anchor="w", pady=(10, 20))

        acciones = ttk.Frame(tarjeta, style="Card.TFrame")
        acciones.pack(fill="x", pady=(0, 16))

        ttk.Button(
            acciones,
            text="Agregar PDFs",
            command=self.agregar_archivos,
            style="Accent.TButton",
        ).pack(side="left")

        ttk.Button(
            acciones,
            text="Limpiar lista",
            command=self.limpiar_lista,
            style="Ghost.TButton",
        ).pack(side="left", padx=(10, 0))

        self.resumen_var = tk.StringVar(value="No hay archivos cargados.")
        ttk.Label(
            tarjeta,
            textvariable=self.resumen_var,
            style="Body.TLabel",
            font=("Segoe UI", 10, "italic"),
        ).pack(anchor="w", pady=(0, 10))

        lista_frame = ttk.Frame(tarjeta, style="Card.TFrame")
        lista_frame.pack(fill="both", expand=True)

        self.lista = tk.Listbox(
            lista_frame,
            font=("Segoe UI", 10),
            activestyle="none",
            bg="#fffdf8",
            fg="#162033",
            selectbackground="#2a9d8f",
            selectforeground="white",
            relief="flat",
            highlightthickness=1,
            highlightbackground="#d8d5cf",
        )
        self.lista.pack(side="left", fill="both", expand=True)

        scrollbar = ttk.Scrollbar(lista_frame, orient="vertical", command=self.lista.yview)
        scrollbar.pack(side="right", fill="y")
        self.lista.config(yscrollcommand=scrollbar.set)

        acciones_inferiores = ttk.Frame(tarjeta, style="Card.TFrame")
        acciones_inferiores.pack(fill="x", pady=(18, 0))

        ttk.Button(
            acciones_inferiores,
            text="Quitar seleccionado",
            command=self.quitar_seleccionado,
            style="Ghost.TButton",
        ).pack(side="left")

        ttk.Button(
            acciones_inferiores,
            text="Generar ZIP",
            command=self.generar_zip,
            style="Accent.TButton",
        ).pack(side="right")

        self.estado_var = tk.StringVar(
            value="Listo para procesar. Los archivos originales no se modifican."
        )
        ttk.Label(
            tarjeta,
            textvariable=self.estado_var,
            style="Body.TLabel",
            font=("Segoe UI", 10),
            wraplength=620,
            justify="left",
        ).pack(anchor="w", pady=(18, 0))

    def agregar_archivos(self) -> None:
        seleccionados = filedialog.askopenfilenames(
            title="Seleccionar archivos PDF",
            filetypes=[("Archivos PDF", "*.pdf")],
        )
        if not seleccionados:
            return

        existentes = {str(path) for path in self.archivos}
        nuevos = 0
        for ruta in seleccionados:
            path = Path(ruta)
            if str(path) not in existentes:
                self.archivos.append(path)
                self.lista.insert("end", path.name)
                existentes.add(str(path))
                nuevos += 1

        self._actualizar_resumen()
        self.estado_var.set(f"Se agregaron {nuevos} archivo(s) a la lista.")

    def limpiar_lista(self) -> None:
        self.archivos.clear()
        self.lista.delete(0, "end")
        self._actualizar_resumen()
        self.estado_var.set("La lista fue vaciada.")

    def quitar_seleccionado(self) -> None:
        seleccion = self.lista.curselection()
        if not seleccion:
            self.estado_var.set("Selecciona un archivo de la lista para quitarlo.")
            return

        indice = seleccion[0]
        self.lista.delete(indice)
        del self.archivos[indice]
        self._actualizar_resumen()
        self.estado_var.set("El archivo seleccionado fue quitado.")

    def generar_zip(self) -> None:
        if not self.archivos:
            messagebox.showwarning("Sin archivos", "Agrega al menos un PDF antes de continuar.")
            return

        destino = filedialog.asksaveasfilename(
            title="Guardar archivo ZIP",
            defaultextension=".zip",
            initialfile="resultado.zip",
            filetypes=[("Archivo ZIP", "*.zip")],
        )
        if not destino:
            self.estado_var.set("La exportacion fue cancelada.")
            return

        errores: list[str] = []
        generados = 0

        with tempfile.TemporaryDirectory() as temp_dir:
            base = Path(temp_dir)
            renombrados = base / "Renombrados"
            renombrados.mkdir(exist_ok=True)

            for pdf in self.archivos:
                try:
                    nombre = extraer_nombre(pdf)
                    if not nombre:
                        errores.append(f"No se pudo leer el nombre en {pdf.name}")
                        continue

                    archivo_destino = self._ruta_disponible(renombrados / f"{nombre}.pdf")
                    shutil.copy2(pdf, archivo_destino)
                    generados += 1
                except Exception as exc:
                    errores.append(f"{pdf.name}: {exc}")

            if generados == 0:
                detalle = "\n".join(errores[:10]) or "No se pudo generar ningun archivo."
                messagebox.showerror("Sin resultados", detalle)
                self.estado_var.set("No se pudo generar el ZIP.")
                return

            with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as zipf:
                for archivo in sorted(renombrados.glob("*.pdf")):
                    zipf.write(archivo, archivo.name)

        if errores:
            detalle = "\n".join(errores[:10])
            messagebox.showwarning(
                "Proceso completado con observaciones",
                f"Se genero el ZIP con {generados} archivo(s).\n\n{detalle}",
            )
            self.estado_var.set(
                f"ZIP generado con {generados} archivo(s). Hubo {len(errores)} observacion(es)."
            )
        else:
            messagebox.showinfo(
                "Proceso completado",
                f"Se genero el ZIP correctamente con {generados} archivo(s).",
            )
            self.estado_var.set(f"ZIP generado correctamente con {generados} archivo(s).")

    def _ruta_disponible(self, destino: Path) -> Path:
        if not destino.exists():
            return destino

        contador = 2
        while True:
            candidata = destino.with_name(f"{destino.stem} ({contador}){destino.suffix}")
            if not candidata.exists():
                return candidata
            contador += 1

    def _actualizar_resumen(self) -> None:
        cantidad = len(self.archivos)
        if cantidad == 0:
            self.resumen_var.set("No hay archivos cargados.")
        elif cantidad == 1:
            self.resumen_var.set("Hay 1 archivo listo para procesar.")
        else:
            self.resumen_var.set(f"Hay {cantidad} archivos listos para procesar.")


def main() -> None:
    root = tk.Tk()
    ProcesadorApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
