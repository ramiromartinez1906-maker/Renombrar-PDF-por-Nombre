from __future__ import annotations

import os
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


HOST = "127.0.0.1"
PORT = 8000
BASE_DIR = Path(__file__).resolve().parent
WEB_DIR = BASE_DIR / "frontend" / "dist"


def puerto_disponible(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        return sock.connect_ex((host, port)) != 0


def abrir_servidor() -> None:
    if not WEB_DIR.exists():
        raise FileNotFoundError(f"No se encontro la carpeta web: {WEB_DIR}")

    handler = partial(SimpleHTTPRequestHandler, directory=str(WEB_DIR))
    httpd = ThreadingHTTPServer((HOST, PORT), handler)
    print(f"Pagina disponible en http://localhost:{PORT}")
    httpd.serve_forever()


def relanzar_en_nueva_ventana() -> None:
    creation_flags = 0
    if os.name == "nt":
        creation_flags = subprocess.CREATE_NEW_CONSOLE

    subprocess.Popen(
        [sys.executable, str(Path(__file__).resolve()), "--server"],
        cwd=str(BASE_DIR),
        creationflags=creation_flags,
    )


def main() -> None:
    if "--server" in sys.argv:
        abrir_servidor()
        return

    if puerto_disponible(HOST, PORT):
        relanzar_en_nueva_ventana()
        time.sleep(1.5)

    webbrowser.open(f"http://localhost:{PORT}")


if __name__ == "__main__":
    main()
