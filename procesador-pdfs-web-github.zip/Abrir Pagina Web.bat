@echo off
setlocal
cd /d "%~dp0"
python abrir_pagina_web.py
if errorlevel 1 (
    echo.
    echo No se pudo abrir la pagina web.
    pause
)
endlocal
