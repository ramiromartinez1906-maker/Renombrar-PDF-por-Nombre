from __future__ import annotations

import socket
import threading
import time
from pathlib import Path

import webview

from backend.app import app


HOST = "127.0.0.1"
PORT = 5000


def wait_for_server(host: str, port: int, timeout: float = 15.0) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection((host, port), timeout=1):
                return
        except OSError:
            time.sleep(0.2)
    raise RuntimeError("No se pudo iniciar el servidor local.")


def start_server() -> None:
    app.run(host=HOST, port=PORT, debug=False, use_reloader=False)


def main() -> None:
    dist_index = Path(__file__).resolve().parent / "frontend" / "dist" / "index.html"
    if not dist_index.exists():
        raise FileNotFoundError(
            "No se encontro el frontend compilado. Ejecuta `npm.cmd run build` en frontend."
        )

    server_thread = threading.Thread(target=start_server, daemon=True)
    server_thread.start()
    wait_for_server(HOST, PORT)

    webview.create_window(
        "Procesador de PDFs por nombre",
        f"http://{HOST}:{PORT}",
        width=1100,
        height=760,
        min_size=(900, 650),
    )
    webview.start()


if __name__ == "__main__":
    main()
