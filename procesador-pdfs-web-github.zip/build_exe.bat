@echo off
setlocal
cd /d "%~dp0"

python -m pip install pyinstaller

python -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --windowed ^
  --onedir ^
  --name "Procesador de PDFs por nombre" ^
  --add-data "backend;backend" ^
  app_escritorio.py

if errorlevel 1 (
    echo.
    echo Fallo la compilacion del ejecutable.
    pause
    exit /b 1
)

echo.
echo Ejecutable generado en la carpeta dist.
pause
endlocal
